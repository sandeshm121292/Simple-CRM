<?php
include('class.dbconnect.php');
$connect=new dbconnect();

	
if(isset($_POST['submit']) )
{
$id=trim($_POST['name']);

	$q1="select * from customer_master where id='$id'";
	$sth1=$connect->query($q1);
	$result1=$connect->display($sth1);

	$name=$result1['name'];

$age=trim($_POST['age']);
$height=trim($_POST['height']);
$weight=trim($_POST['weight']);
if($weight > 0 && $height > 0)
{
	$bmi=$weight/($height/100*$height/100);
}

$remarks=trim($_POST['remarks']);
$body_fat=trim($_POST['body_fat']);
$hydration=trim($_POST['hydration']);
$muscle_mass=trim($_POST['muscle_mass']);
$bone_density=trim($_POST['bone_density']);
$calories=trim($_POST['calories']);
$body_frame=trim($_POST['body_frame']);


$q="insert into fitness_master (name, age, height , weight, bmi , remarks , body_fat , hydration , muscle_mass ,bone_density, calories, body_frame)
values('$name', '$age', '$height', '$weight', '$bmi', '$remarks', '$body_fat', '$hydration','$muscle_mass','$bone_density','$calories','$body_frame')";
$sth=$connect->query($q);

if($sth)
 {
		
		echo "<script> alert('Success'); window.location='fitness_assesment.php'; </script>";
  		
 }
 else 
 {
		echo "<script> alert('Success'); window.location='fitness_assesment.php'; </script>";
 }
}

?>