<?php
include('class.dbconnect.php');
$connect=new dbconnect();
$a=$_SESSION['email'];
	if($a)
	{
	?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>User</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="css/plugins/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="css/plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<style type="text/css">

    #printable { display: none; }

    @media print
    {
    	#non-printable { display: none; }
    	#printable { display: block; }
    }
    </style>
    <script type="text/javascript">
    function printpage() {
        //Get the print button and put it into a variable
        var printButton = document.getElementById("printpagebutton");
        //Set the print button visibility to 'hidden' 
        printButton.style.visibility = 'hidden';
        //Print the page content
        window.print()
        //Set the print button to 'visible' again 
        //[Delete this line if you want it to stay hidden after printing]
        printButton.style.visibility = 'visible';
    }
</script>
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html"> Sandeep's Dance Company</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="profile.php"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="settings.php"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a  href="dashboard.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        
						<li>
                            <a  href="add_customer.php"><i class="fa fa-user fa-fw"></i> Customers</a>
                        </li>
                        <li>
                            <a class="active" href="manage_customer.php"><i class="fa fa-search fa-fw"></i> Manage Customers</a>
                        </li>
                        <li>
                            <a  href="fitness_assesment.php"><i class="fa fa-plus fa-fw"></i> Fitness Assesment</a>
                        </li>
						<li>
                            <a  href="add_admin.php"><i class="fa fa-user fa-fw"></i> Add New Admin</a>
                        </li>
						<li>
                            <a href="mail.php"><i class="fa fa-envelope fa-fw"></i> Mail</a>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row" id="non-printable">
                <div class="col-lg-12">
                    <h1 class="page-header">Customer</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading" id="non-printable">
                           View Customer
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body" >
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                   
								   <?php
										
										$id=$_GET['view_id'];
										
										$q="select * from fitness_master where id='$id'";
										$sth=$connect->query($q);
										while($res=$connect->display($sth))
										{
									?>
							<div class="box-content">
								<table class="table table-striped table-bordered responsive">
									<thead>
										<tr>
											<th>Fields</th>
											<th>Details</th>
										</tr>
									</thead>
                                    <tbody>
										<tr>
											<td>Name</td>
											<td class="center"><?php echo $res['name'];?></td>
										</tr>
										<tr>
											<td>Age</td>
											<td class="center"><?php echo $res['age'];?></td>
										</tr>
										<tr>
											<td>Height</td>
											<td class="center"><?php echo $res['height'];?></td>
										</tr>
										<tr>
											<td>Weight</td>
											<td class="center"><?php echo $res['weight'];?></td>
										</tr>
										<tr>
											<td>BMI</td>
											<td class="center"><?php echo $res['bmi'];?></td>
										</tr>
										<tr>
											<td>Remarks</td>
											<td class="center"><?php echo $res['remarks'];?></td>
										</tr>
                                        <tr>
											<td>Body Fat</td>
											<td class="center"><?php echo $res['body_fat'];?></td>
										</tr>
										<tr>
											<td>Hydration</td>
											<td class="center"><?php echo $res['hydration'];?></td>
										</tr>
										<tr>
											<td>Muscle Mass</td>
											<td class="center"><?php echo $res['muscle_mass'];?></td>
										</tr>
										<tr>
											<td>Bone Density</td>
											<td class="center"><?php echo $res['bone_density'];?></td>
										</tr>
										<tr>
											<td>Calories</td>
											<td class="center"><?php echo $res['calories'];?></td>
										</tr>
										<tr>
											<td>Body Frame</td>
											<td class="center"><?php echo $res['body_frame'];?></td>
										</tr>
										<tr>
											<td>Date</td>
											<td class="center"><?php echo $res['date'];?></td>
										</tr>
                                    </tbody>
									<form> 
										<input id="printpagebutton" value="Print"  class="btn btn-info" type="button"  onclick="printpage()"/> 
									</form>
										
										
										
                                </table>
                                <?php
                                }
?>
                            </div>
							
							
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
					
                </div>
                <!-- /.col-lg-12 -->
				
            </div>
			
        </div>
		  
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
	<footer class=" navbar-default" id="non-printable">
	<p align="center">All Rights Reserved<span> @ </span> 2015</p>
	</footer>
    <!-- jQuery Version 1.11.0 -->
    <script src="js/jquery-1.11.0.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="js/plugins/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="js/plugins/dataTables/dataTables.bootstrap.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
    });
    </script>

</body>

</html>
<?php 
}
else
	{
		header('Location: index.php');
	}
?>