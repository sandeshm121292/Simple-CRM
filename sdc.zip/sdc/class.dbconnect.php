<?php
	class dbconnect
	{
		public $con;
		function __construct()
		{
			date_default_timezone_set("Asia/Kolkata");
			session_start();
			error_reporting(0);
			include('config.php');
			$con=mysqli_connect("$host_name","$db_username","$db_password","$db_name");
			if(!$con)
			{
				echo "<script> alert('Database Configration is Not vaild'); </script>";
				exit;
			}
			else 
			{
				$this->con=$con;
			}
		}
		function query($q)
		{
			$sth=mysqli_query($this->con,$q);
			if(!$sth)
			{
				echo "<script> alert('dup'); </script>";
				exit;
			}
			else 
			{
				return $sth;
			}
		}
		
		function maximum($q)
		{
			$sth=mysqli_query($this->con,$q);
			
			if(!$sth)
			{
				echo "<script> alert('error'); </script>";
				exit;
			}
			else 
			{
				$result=mysqli_fetch_array($sth);
				 return $result[0]+1;
				 
			}
		}
		function maximum1($q)
		{
			$sth=mysqli_query($this->con,$q);
			
			if(!$sth)
			{
				echo "<script> alert('error'); </script>";
				exit;
			}
			else 
			{
				$result=mysqli_fetch_array($sth);
				return $result[0];
			}
		}
		
		function count($sth)
		{
			$count=mysqli_num_rows($sth);
			return $count;
		}
		function display($sth)
		{
			$result=mysqli_fetch_assoc($sth);
			return $result;
		}
	}
?>