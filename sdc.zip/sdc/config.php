<?php
	$host_name="localhost";
	$db_username="root";
	$db_password="";
	$db_name="sdc";
?>
