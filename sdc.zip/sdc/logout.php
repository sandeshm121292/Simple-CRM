<?php
	
	  include('class.dbconnect.php');
	  $connect=new dbconnect();
      session_destroy();
	 
     echo "<script> alert('Successfully Logged Out'); window.location='index.php'; </script>";
	
?>