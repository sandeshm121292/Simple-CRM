<table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Date</th>
                                            <th>BMI</th>
                                            <th>Age</th>
											<th>Height</th>
											<th>Weight</th>
                                        </tr>
                                    </thead>
                                    <tbody>
										<?php 
											
											$q="select *from fitness_master";
											$sth=$connect->query($q);
											while($result=$connect->display($sth))
											{ 
										?>
                           
										<tr>
										<td><?php echo $result['name'];?></td>
										<td><?php echo $result['date'];?></td>
										<td><?php echo $result['bmi'];?></td>
										<td><?php echo $result['age'];?></td>
										<td><?php echo $result['height'];?></td>
										<td><?php echo $result['weight'];?></td>
										<td align="center">
										<a class="btn btn-danger" href="?delete_id=<?php echo $result['id']?>&amp;action=delete">
										<i class="glyphicon glyphicon-trash icon-white"></i>
										Delete
										</a>
										<a class="btn btn-success" href="view_customer.php?view_id=<?php echo $result['id']; ?>">
										<i class="glyphicon glyphicon-zoom-in icon-white"></i>
										View
										</a>
										</td>
										
										</tr>
										<?php } ?>
                                        
                                    </tbody>
                                </table>